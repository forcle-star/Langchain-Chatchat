class ModelContainer:
    def __init__(self):
        self.MODEL = None
        self.DATABASE = None

model_container = ModelContainer()
